"""
statistics.py
-------------
Statistical tests for HR attrition analysis.
Uses chi-square for categorical variables and Mann–Whitney U / t-test for numerical.
"""

import pandas as pd
import numpy as np
from scipy import stats
import streamlit as st


# ─────────────────────────────────────────────────────────────────
# Individual tests
# ─────────────────────────────────────────────────────────────────

def chi_square_test(df: pd.DataFrame, col: str, target: str = "Attrition") -> dict:
    """
    Chi-square test of independence between `col` and `target`.
    Returns statistic, p-value, degrees of freedom, and interpretation.
    """
    ct   = pd.crosstab(df[col], df[target])
    chi2, p, dof, _ = stats.chi2_contingency(ct)
    n    = ct.values.sum()
    # Cramér's V (effect size)
    v    = np.sqrt(chi2 / (n * (min(ct.shape) - 1))) if min(ct.shape) > 1 else np.nan
    sig  = p < 0.05

    return {
        "Variable":      col,
        "Test":          "Chi-Square",
        "Statistic":     round(chi2, 4),
        "p-value":       round(p, 6),
        "df":            dof,
        "Effect (V)":    round(v, 4) if not np.isnan(v) else "—",
        "Significant":   "Yes ✓" if sig else "No",
        "Interpretation": (
            f"There is {'a statistically significant' if sig else 'no significant'} "
            f"association between {col} and Attrition at the 5% level "
            f"(χ²={chi2:.2f}, p={p:.4f}, Cramér's V={v:.3f})."
        ),
    }


def mannwhitney_test(df: pd.DataFrame, col: str, target: str = "Attrition") -> dict:
    """
    Mann–Whitney U test comparing `col` between employees who stayed and left.
    Returns statistic, p-value, and effect size (rank-biserial r).
    """
    grp_yes = df.loc[df[target] == "Yes", col].dropna()
    grp_no  = df.loc[df[target] == "No",  col].dropna()

    if len(grp_yes) < 5 or len(grp_no) < 5:
        return {"Variable": col, "Test": "Mann–Whitney U", "Statistic": "—",
                "p-value": "—", "df": "—", "Effect (r)": "—",
                "Significant": "—", "Interpretation": "Insufficient data."}

    u_stat, p = stats.mannwhitneyu(grp_yes, grp_no, alternative="two-sided")
    n1, n2    = len(grp_yes), len(grp_no)
    r         = 1 - (2 * u_stat) / (n1 * n2)   # rank-biserial r
    sig       = p < 0.05

    return {
        "Variable":       col,
        "Test":           "Mann–Whitney U",
        "Statistic":      round(u_stat, 2),
        "p-value":        round(p, 6),
        "df":             f"n₁={n1}, n₂={n2}",
        "Effect (r)":     round(abs(r), 4),
        "Significant":    "Yes ✓" if sig else "No",
        "Interpretation": (
            f"The distribution of {col} differs {'significantly' if sig else 'non-significantly'} "
            f"between employees who left vs stayed "
            f"(U={u_stat:.0f}, p={p:.4f}, r={abs(r):.3f}). "
            f"Median Left={grp_yes.median():.1f}, Median Stayed={grp_no.median():.1f}."
        ),
    }


# ─────────────────────────────────────────────────────────────────
# Batch test runner
# ─────────────────────────────────────────────────────────────────

@st.cache_data(show_spinner=False)
def run_all_statistical_tests(_df: pd.DataFrame) -> pd.DataFrame:
    """
    Run chi-square tests on categorical variables and Mann–Whitney tests
    on numerical variables. Returns a combined results DataFrame.
    """
    categorical_vars = [
        "BusinessTravel", "Department", "EducationField", "Gender",
        "JobRole", "MaritalStatus", "OverTime", "AgeGroup",
        "IncomeGroup", "TenureGroup", "DistanceGroup",
        "JobSatisfactionLabel", "EnvironmentSatisfactionLabel",
        "WorkLifeBalanceLabel", "JobInvolvementLabel",
    ]
    numerical_vars = [
        "Age", "DailyRate", "DistanceFromHome", "HourlyRate",
        "JobLevel", "MonthlyIncome", "MonthlyRate",
        "NumCompaniesWorked", "PercentSalaryHike",
        "StockOptionLevel", "TotalWorkingYears", "TrainingTimesLastYear",
        "YearsAtCompany", "YearsInCurrentRole",
        "YearsSinceLastPromotion", "YearsWithCurrManager",
    ]

    results = []

    for col in categorical_vars:
        if col in _df.columns and _df[col].nunique() > 1:
            try:
                results.append(chi_square_test(_df, col))
            except Exception:
                pass

    for col in numerical_vars:
        if col in _df.columns:
            try:
                results.append(mannwhitney_test(_df, col))
            except Exception:
                pass

    return pd.DataFrame(results)


def get_significant_vars(stats_df: pd.DataFrame) -> pd.DataFrame:
    """Return only statistically significant rows."""
    return stats_df[stats_df["Significant"] == "Yes ✓"].copy()
