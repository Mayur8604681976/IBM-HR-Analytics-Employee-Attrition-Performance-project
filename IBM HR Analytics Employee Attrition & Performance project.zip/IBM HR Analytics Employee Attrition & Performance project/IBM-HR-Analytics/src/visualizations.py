"""
visualizations.py
-----------------
Plotly chart factory functions for the Streamlit dashboard.
All functions return a plotly.graph_objects.Figure.
"""

import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np


# ─────────────────────────────────────────────────────────────────
# Colour palette
# ─────────────────────────────────────────────────────────────────

STAY_COLOR  = "#3b82f6"   # blue  – stayed
LEFT_COLOR  = "#ef4444"   # red   – left
NEUTRAL     = "#6b7280"   # grey
PALETTE     = px.colors.qualitative.Plotly
HEATMAP_CS  = "RdYlGn_r"

FONT_FAMILY = "Inter, -apple-system, Segoe UI, sans-serif"


def _base_layout(fig: go.Figure, title: str = "") -> go.Figure:
    """Apply standard layout defaults."""
    fig.update_layout(
        title=dict(text=title, font=dict(size=16, family=FONT_FAMILY, color="#1f2328")),
        font=dict(family=FONT_FAMILY, size=13, color="#374151"),
        paper_bgcolor="#ffffff",
        plot_bgcolor="#f9fafb",
        legend=dict(bgcolor="rgba(0,0,0,0)", borderwidth=0),
        margin=dict(l=40, r=20, t=50, b=40),
    )
    fig.update_xaxes(showgrid=False, linecolor="#e5e7eb")
    fig.update_yaxes(showgrid=True,  gridcolor="#e5e7eb", linecolor="#e5e7eb")
    return fig


# ─────────────────────────────────────────────────────────────────
# Attrition charts
# ─────────────────────────────────────────────────────────────────

def attrition_donut(left: int, stayed: int) -> go.Figure:
    """Overall attrition donut chart."""
    fig = go.Figure(go.Pie(
        labels=["Left", "Stayed"],
        values=[left, stayed],
        hole=0.65,
        marker_colors=[LEFT_COLOR, STAY_COLOR],
        textinfo="label+percent",
        hovertemplate="%{label}: %{value} (%{percent})<extra></extra>",
    ))
    fig.update_layout(
        showlegend=True,
        margin=dict(l=10, r=10, t=30, b=10),
        paper_bgcolor="#ffffff",
        font=dict(family=FONT_FAMILY),
    )
    return fig


def attrition_rate_bar(grp: pd.DataFrame, col: str, title: str = "") -> go.Figure:
    """
    Grouped bar chart showing employee count and attrition rate per category.
    Uses dual-axis: bars = count, line = attrition rate.
    """
    grp = grp.sort_values("AttritionRate", ascending=False)
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Bar(
        x=grp[col].astype(str), y=grp["Stayed"],
        name="Stayed", marker_color=STAY_COLOR,
        hovertemplate="%{x}<br>Stayed: %{y}<extra></extra>",
    ), secondary_y=False)
    fig.add_trace(go.Bar(
        x=grp[col].astype(str), y=grp["Left"],
        name="Left", marker_color=LEFT_COLOR,
        hovertemplate="%{x}<br>Left: %{y}<extra></extra>",
    ), secondary_y=False)
    fig.add_trace(go.Scatter(
        x=grp[col].astype(str), y=grp["AttritionRate"],
        name="Attrition %", mode="lines+markers",
        marker=dict(size=8, color="#f59e0b"),
        line=dict(color="#f59e0b", width=2),
        hovertemplate="%{x}<br>Attrition rate: %{y:.1f}%<extra></extra>",
    ), secondary_y=True)
    fig.update_layout(
        barmode="stack",
        title=dict(text=title or f"Attrition by {col}", font=dict(size=15, family=FONT_FAMILY)),
        paper_bgcolor="#ffffff", plot_bgcolor="#f9fafb",
        font=dict(family=FONT_FAMILY),
        legend=dict(orientation="h", y=-0.15),
        margin=dict(l=40, r=40, t=50, b=60),
    )
    fig.update_yaxes(title_text="Employee Count", secondary_y=False, gridcolor="#e5e7eb")
    fig.update_yaxes(title_text="Attrition Rate (%)", secondary_y=True, showgrid=False)
    return fig


def attrition_heatmap(pivot: pd.DataFrame, title: str = "") -> go.Figure:
    """Heatmap of attrition rates from a pivot table."""
    fig = px.imshow(
        pivot.fillna(0),
        color_continuous_scale=HEATMAP_CS,
        text_auto=".1f",
        aspect="auto",
        title=title,
        labels=dict(color="Attrition %"),
    )
    fig.update_layout(
        paper_bgcolor="#ffffff",
        font=dict(family=FONT_FAMILY),
        margin=dict(l=60, r=20, t=60, b=60),
        coloraxis_colorbar=dict(title="Rate %"),
    )
    return fig


# ─────────────────────────────────────────────────────────────────
# Distribution charts
# ─────────────────────────────────────────────────────────────────

def age_histogram(df: pd.DataFrame) -> go.Figure:
    """Age distribution histogram coloured by attrition."""
    fig = px.histogram(
        df, x="Age", color="Attrition",
        color_discrete_map={"No": STAY_COLOR, "Yes": LEFT_COLOR},
        barmode="overlay", nbins=20,
        title="Age Distribution by Attrition",
        labels={"Age": "Age (years)", "count": "Employees"},
        opacity=0.75,
    )
    return _base_layout(fig)


def income_box(df: pd.DataFrame) -> go.Figure:
    """Box plot of monthly income by attrition status."""
    fig = px.box(
        df, x="Attrition", y="MonthlyIncome",
        color="Attrition",
        color_discrete_map={"No": STAY_COLOR, "Yes": LEFT_COLOR},
        title="Monthly Income Distribution by Attrition",
        labels={"MonthlyIncome": "Monthly Income ($)", "Attrition": "Attrition"},
        points="outliers",
    )
    return _base_layout(fig)


def income_by_role_box(df: pd.DataFrame) -> go.Figure:
    """Box plot of monthly income per job role."""
    order = (
        df.groupby("JobRole")["MonthlyIncome"].median()
        .sort_values(ascending=False).index.tolist()
    )
    fig = px.box(
        df, x="JobRole", y="MonthlyIncome",
        color="Attrition",
        color_discrete_map={"No": STAY_COLOR, "Yes": LEFT_COLOR},
        category_orders={"JobRole": order},
        title="Monthly Income by Job Role & Attrition",
        labels={"MonthlyIncome": "Monthly Income ($)", "JobRole": "Job Role"},
        points=False,
    )
    fig.update_xaxes(tickangle=-30)
    return _base_layout(fig)


def satisfaction_bar(df: pd.DataFrame, sat_col: str, label_col: str) -> go.Figure:
    """Grouped bar chart of attrition rate by satisfaction level."""
    from src.analysis import attrition_by_column
    grp = df.groupby(label_col, observed=True).agg(
        Total=("AttritionFlag", "count"),
        Left=("AttritionFlag", "sum"),
    ).reset_index()
    grp["AttritionRate"] = (grp["Left"] / grp["Total"] * 100).round(2)
    sat_order = ["Low", "Medium", "High", "Very High", "Bad", "Good", "Better", "Best"]
    present_order = [o for o in sat_order if o in grp[label_col].values]

    fig = px.bar(
        grp, x=label_col, y="AttritionRate",
        color="AttritionRate",
        color_continuous_scale="Reds",
        text="AttritionRate",
        category_orders={label_col: present_order},
        title=f"Attrition Rate by {sat_col.replace('Label', '')}",
        labels={"AttritionRate": "Attrition Rate (%)", label_col: sat_col.replace("Label", "")},
    )
    fig.update_traces(texttemplate="%{text:.1f}%", textposition="outside")
    return _base_layout(fig)


def gender_donut(df: pd.DataFrame) -> go.Figure:
    """Donut chart of gender distribution."""
    counts = df["Gender"].value_counts()
    fig = go.Figure(go.Pie(
        labels=counts.index.tolist(),
        values=counts.values.tolist(),
        hole=0.55,
        marker_colors=["#3b82f6", "#f472b6"],
    ))
    fig.update_layout(title="Gender Distribution", paper_bgcolor="#ffffff",
                      font=dict(family=FONT_FAMILY), margin=dict(t=40))
    return fig


def marital_bar(df: pd.DataFrame) -> go.Figure:
    """Bar chart of attrition rate by marital status."""
    from src.analysis import attrition_by_column
    grp = attrition_by_column(df, "MaritalStatus")
    fig = px.bar(
        grp, x="MaritalStatus", y="AttritionRate",
        color="AttritionRate", color_continuous_scale="Reds",
        text="AttritionRate", title="Attrition Rate by Marital Status",
    )
    fig.update_traces(texttemplate="%{text:.1f}%", textposition="outside")
    return _base_layout(fig)


def education_bar(df: pd.DataFrame) -> go.Figure:
    """Bar chart of employee count by education level."""
    order = ["Below College", "College", "Bachelor", "Master", "Doctor"]
    grp   = df["EducationLabel"].value_counts().reindex(order).reset_index()
    grp.columns = ["Education", "Count"]
    fig = px.bar(grp, x="Education", y="Count", color="Count",
                 color_continuous_scale="Blues",
                 title="Education Level Distribution",
                 category_orders={"Education": order})
    return _base_layout(fig)


def travel_bar(df: pd.DataFrame) -> go.Figure:
    """Dual-axis bar chart of attrition by business travel."""
    from src.analysis import attrition_by_column
    grp = attrition_by_column(df, "BusinessTravel")
    return attrition_rate_bar(grp, "BusinessTravel", "Attrition by Business Travel")


def correlation_heatmap(df: pd.DataFrame) -> go.Figure:
    """Correlation heatmap for numerical columns vs AttritionFlag."""
    num_cols = [
        "Age", "DailyRate", "DistanceFromHome", "EnvironmentSatisfaction",
        "HourlyRate", "JobInvolvement", "JobLevel", "JobSatisfaction",
        "MonthlyIncome", "MonthlyRate", "NumCompaniesWorked",
        "PercentSalaryHike", "PerformanceRating", "RelationshipSatisfaction",
        "StockOptionLevel", "TotalWorkingYears", "TrainingTimesLastYear",
        "WorkLifeBalance", "YearsAtCompany", "YearsInCurrentRole",
        "YearsSinceLastPromotion", "YearsWithCurrManager", "AttritionFlag",
    ]
    present = [c for c in num_cols if c in df.columns]
    corr    = df[present].corr().round(3)

    # Show only correlations with AttritionFlag sorted
    if "AttritionFlag" in corr.columns:
        attr_corr = corr["AttritionFlag"].drop("AttritionFlag").sort_values()
        fig = go.Figure(go.Bar(
            x=attr_corr.values, y=attr_corr.index, orientation="h",
            marker_color=[LEFT_COLOR if v > 0 else STAY_COLOR for v in attr_corr.values],
            hovertemplate="%{y}: %{x:.3f}<extra></extra>",
        ))
        fig.update_layout(
            title="Correlation with Attrition (Pearson)",
            xaxis_title="Correlation Coefficient",
            paper_bgcolor="#ffffff", plot_bgcolor="#f9fafb",
            font=dict(family=FONT_FAMILY),
            margin=dict(l=160, r=20, t=50, b=40),
        )
        return fig
    return go.Figure()


def scatter_income_age(df: pd.DataFrame) -> go.Figure:
    """Scatter of monthly income vs age coloured by attrition."""
    fig = px.scatter(
        df, x="Age", y="MonthlyIncome", color="Attrition",
        color_discrete_map={"No": STAY_COLOR, "Yes": LEFT_COLOR},
        opacity=0.6, title="Monthly Income vs Age",
        labels={"MonthlyIncome": "Monthly Income ($)", "Age": "Age (years)"},
        hover_data=["JobRole", "Department"],
    )
    return _base_layout(fig)


def tenure_attrition_line(grp: pd.DataFrame, col_bin: str) -> go.Figure:
    """Line chart of attrition rate across tenure bins."""
    fig = px.line(
        grp, x=col_bin, y="AttritionRate", markers=True,
        title=f"Attrition Rate across {col_bin.replace('_bin', '')} Bins",
        labels={"AttritionRate": "Attrition Rate (%)", col_bin: ""},
    )
    fig.update_traces(line_color=LEFT_COLOR, marker=dict(size=9))
    return _base_layout(fig)


def overtime_wlb_heatmap(df: pd.DataFrame) -> go.Figure:
    """Heatmap of average work-life balance score by overtime and job role."""
    pivot = df.pivot_table(
        index="JobRole", columns="OverTime",
        values="WorkLifeBalance", aggfunc="mean"
    ).round(2)
    fig = px.imshow(
        pivot, text_auto=".2f", aspect="auto",
        color_continuous_scale="RdYlGn",
        title="Avg Work-Life Balance by Job Role & Overtime",
    )
    fig.update_layout(paper_bgcolor="#ffffff", font=dict(family=FONT_FAMILY))
    return fig


def segment_heatmap(seg_df: pd.DataFrame, row_col: str, col_col: str) -> go.Figure:
    """Heatmap from segment analysis results."""
    if seg_df.empty or row_col not in seg_df.columns or col_col not in seg_df.columns:
        return go.Figure()
    pivot = seg_df.pivot_table(
        index=row_col, columns=col_col,
        values="AttritionRate", aggfunc="mean"
    ).round(2)
    fig = px.imshow(
        pivot, text_auto=".1f", aspect="auto",
        color_continuous_scale=HEATMAP_CS,
        title=f"Attrition Rate: {row_col} × {col_col}",
        labels=dict(color="Attrition %"),
    )
    fig.update_layout(paper_bgcolor="#ffffff", font=dict(family=FONT_FAMILY))
    return fig
