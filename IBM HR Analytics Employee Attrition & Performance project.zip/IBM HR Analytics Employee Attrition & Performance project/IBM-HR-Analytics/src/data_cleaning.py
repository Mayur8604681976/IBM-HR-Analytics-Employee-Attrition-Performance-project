"""
data_cleaning.py
----------------
Cleans the raw DataFrame and engineers derived features.
"""

import pandas as pd
import numpy as np
import streamlit as st

from src.data_loader import load_raw_data, drop_constant_columns, validate_expected_columns


# ------------------------------------------------------------------
# Ordinal encodings used only in ML / statistical contexts
# ------------------------------------------------------------------
EDUCATION_MAP = {1: "Below College", 2: "College", 3: "Bachelor", 4: "Master", 5: "Doctor"}
ENV_SAT_MAP   = {1: "Low", 2: "Medium", 3: "High", 4: "Very High"}
JOB_INV_MAP   = {1: "Low", 2: "Medium", 3: "High", 4: "Very High"}
JOB_SAT_MAP   = {1: "Low", 2: "Medium", 3: "High", 4: "Very High"}
PERF_MAP      = {1: "Low", 2: "Good", 3: "Excellent", 4: "Outstanding"}
REL_SAT_MAP   = {1: "Low", 2: "Medium", 3: "High", 4: "Very High"}
WLB_MAP       = {1: "Bad", 2: "Good", 3: "Better", 4: "Best"}


@st.cache_data(show_spinner=False)
def get_clean_data() -> pd.DataFrame:
    """
    Load, clean, and enrich the HR dataset.

    Steps:
    1. Load raw CSV
    2. Validate expected columns
    3. Drop constant / uninformative columns
    4. Remove exact duplicate rows
    5. Fix data types
    6. Add human-readable label columns for ordinal codes
    7. Engineer derived feature columns
    8. Compute Attrition / Overtime flags as integers

    Returns
    -------
    pd.DataFrame — clean, analysis-ready DataFrame
    """
    df = load_raw_data()

    # --- Validate ---
    missing_cols = validate_expected_columns(df)
    if missing_cols:
        raise ValueError(f"Expected columns not found in dataset: {missing_cols}")

    # --- Drop constant columns ---
    df = drop_constant_columns(df)

    # --- Drop duplicates ---
    df = df.drop_duplicates()

    # --- Data types ---
    cat_cols = [
        "Attrition", "BusinessTravel", "Department", "EducationField",
        "Gender", "JobRole", "MaritalStatus", "OverTime",
    ]
    for col in cat_cols:
        if col in df.columns:
            df[col] = df[col].astype("category")

    # --- Ordinal label columns (human-readable) ---
    if "Education" in df.columns:
        df["EducationLabel"] = df["Education"].map(EDUCATION_MAP)
    if "EnvironmentSatisfaction" in df.columns:
        df["EnvironmentSatisfactionLabel"] = df["EnvironmentSatisfaction"].map(ENV_SAT_MAP)
    if "JobInvolvement" in df.columns:
        df["JobInvolvementLabel"] = df["JobInvolvement"].map(JOB_INV_MAP)
    if "JobSatisfaction" in df.columns:
        df["JobSatisfactionLabel"] = df["JobSatisfaction"].map(JOB_SAT_MAP)
    if "PerformanceRating" in df.columns:
        df["PerformanceRatingLabel"] = df["PerformanceRating"].map(PERF_MAP)
    if "RelationshipSatisfaction" in df.columns:
        df["RelationshipSatisfactionLabel"] = df["RelationshipSatisfaction"].map(REL_SAT_MAP)
    if "WorkLifeBalance" in df.columns:
        df["WorkLifeBalanceLabel"] = df["WorkLifeBalance"].map(WLB_MAP)

    # --- Derived: Attrition & Overtime flags ---
    df["AttritionFlag"] = (df["Attrition"] == "Yes").astype(int)
    df["OvertimeFlag"]  = (df["OverTime"]   == "Yes").astype(int)

    # --- Derived: Age Group ---
    bins   = [17, 24, 34, 44, 54, 100]
    labels = ["Under 25", "25–34", "35–44", "45–54", "55+"]
    df["AgeGroup"] = pd.cut(df["Age"], bins=bins, labels=labels)

    # --- Derived: Income Group ---
    inc_q = df["MonthlyIncome"].quantile([0.33, 0.67])
    df["IncomeGroup"] = pd.cut(
        df["MonthlyIncome"],
        bins=[0, inc_q[0.33], inc_q[0.67], df["MonthlyIncome"].max() + 1],
        labels=["Low", "Medium", "High"],
        include_lowest=True,
    )

    # --- Derived: Tenure Group ---
    t_bins   = [-1, 2, 5, 10, 100]
    t_labels = ["New Employee", "Early Career", "Mid Career", "Long Tenure"]
    df["TenureGroup"] = pd.cut(df["YearsAtCompany"], bins=t_bins, labels=t_labels)

    # --- Derived: Distance Group ---
    d_bins   = [0, 5, 15, 100]
    d_labels = ["Near", "Moderate", "Far"]
    df["DistanceGroup"] = pd.cut(df["DistanceFromHome"], bins=d_bins, labels=d_labels)

    return df


def get_summary_kpis(df: pd.DataFrame) -> dict:
    """Calculate top-level workforce KPIs."""
    total    = len(df)
    left     = int(df["AttritionFlag"].sum())
    stayed   = total - left
    rate     = round(left / total * 100, 2) if total > 0 else 0.0
    avg_age  = round(df["Age"].mean(), 1)
    avg_inc  = round(df["MonthlyIncome"].mean(), 0)
    avg_ten  = round(df["YearsAtCompany"].mean(), 1)
    ot_rate  = round(df["OvertimeFlag"].mean() * 100, 1)
    return {
        "total_employees": total,
        "employees_left": left,
        "employees_stayed": stayed,
        "attrition_rate": rate,
        "avg_age": avg_age,
        "avg_monthly_income": avg_inc,
        "avg_tenure": avg_ten,
        "overtime_rate": ot_rate,
    }
