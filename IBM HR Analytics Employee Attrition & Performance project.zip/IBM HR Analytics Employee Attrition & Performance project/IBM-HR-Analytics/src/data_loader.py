"""
data_loader.py
--------------
Handles CSV loading, validation, and initial data-quality reporting.
"""

import os
import pandas as pd
import numpy as np
import streamlit as st


DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "WA_Fn-UseC_-HR-Employee-Attrition.csv")

# Columns that are constant / carry no analytical value in this dataset
CONSTANT_COLUMNS = ["EmployeeCount", "Over18", "StandardHours"]


@st.cache_data(show_spinner=False)
def load_raw_data(path: str = DATA_PATH) -> pd.DataFrame:
    """Load the raw CSV and return a DataFrame without modifications."""
    abs_path = os.path.abspath(path)
    if not os.path.exists(abs_path):
        raise FileNotFoundError(
            f"Dataset not found at '{abs_path}'.\n"
            "Please place 'WA_Fn-UseC_-HR-Employee-Attrition.csv' in the data/ folder."
        )
    df = pd.read_csv(abs_path, encoding="utf-8-sig")
    if df.empty:
        raise ValueError("The dataset is empty.")
    return df


def get_data_quality_report(df: pd.DataFrame) -> dict:
    """
    Generate a data-quality summary dictionary.

    Returns
    -------
    dict with keys: shape, dtypes, missing, duplicates,
                    numerical_cols, categorical_cols,
                    constant_cols, unique_counts, outlier_summary
    """
    report = {}

    report["shape"] = df.shape
    report["dtypes"] = df.dtypes.astype(str).to_dict()

    # Missing values
    missing = df.isnull().sum()
    report["missing"] = missing[missing > 0].to_dict()
    report["missing_pct"] = (missing[missing > 0] / len(df) * 100).round(2).to_dict()

    # Duplicates
    report["duplicate_rows"] = int(df.duplicated().sum())

    # Column type classification
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    report["numerical_cols"] = num_cols
    report["categorical_cols"] = cat_cols

    # Constant columns (zero variance)
    const = [c for c in df.columns if df[c].nunique() <= 1]
    report["constant_cols"] = const

    # Unique value counts for categoricals
    report["unique_counts"] = {c: int(df[c].nunique()) for c in cat_cols}

    # Outlier detection using IQR for numerical columns
    outlier_summary = {}
    for col in num_cols:
        q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
        iqr = q3 - q1
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        n_outliers = int(((df[col] < lower) | (df[col] > upper)).sum())
        if n_outliers > 0:
            outlier_summary[col] = n_outliers
    report["outlier_summary"] = outlier_summary

    return report


def validate_expected_columns(df: pd.DataFrame) -> list[str]:
    """Return a list of any expected columns that are missing from df."""
    expected = [
        "Age", "Attrition", "BusinessTravel", "Department", "DistanceFromHome",
        "Education", "EducationField", "EnvironmentSatisfaction", "Gender",
        "JobInvolvement", "JobLevel", "JobRole", "JobSatisfaction", "MaritalStatus",
        "MonthlyIncome", "NumCompaniesWorked", "OverTime", "PercentSalaryHike",
        "PerformanceRating", "RelationshipSatisfaction", "StockOptionLevel",
        "TotalWorkingYears", "TrainingTimesLastYear", "WorkLifeBalance",
        "YearsAtCompany", "YearsInCurrentRole", "YearsSinceLastPromotion",
        "YearsWithCurrManager",
    ]
    return [c for c in expected if c not in df.columns]


def drop_constant_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Drop columns that carry no analytical information (constant across all rows)."""
    cols_to_drop = [c for c in CONSTANT_COLUMNS if c in df.columns]
    return df.drop(columns=cols_to_drop)


def get_descriptive_stats(df: pd.DataFrame) -> pd.DataFrame:
    """Return descriptive statistics for numerical columns."""
    return df.select_dtypes(include=[np.number]).describe().T.round(2)
