"""
utils.py
--------
Shared utility helpers: download buttons, CSS injection, formatting.
"""

import io
import pandas as pd
import streamlit as st


# ─────────────────────────────────────────────────────────────────
# CSS / Style
# ─────────────────────────────────────────────────────────────────

CUSTOM_CSS = """
<style>
/* ---- Global ---- */
[data-testid="stAppViewContainer"] {
    background: #f3f4f6;
}
[data-testid="stSidebar"] {
    background: #1e293b !important;
}
[data-testid="stSidebar"] * {
    color: #e2e8f0 !important;
}
[data-testid="stSidebar"] .stRadio > label {
    font-weight: 600;
    font-size: 0.85rem;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    color: #94a3b8 !important;
}
[data-testid="stSidebar"] hr {
    border-color: #334155;
}
/* ---- Main content ---- */
.main .block-container {
    padding-top: 1.5rem;
    padding-bottom: 2rem;
    max-width: 1400px;
}
/* ---- KPI card ---- */
.kpi-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    padding: 1.1rem 1.4rem;
    text-align: center;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}
.kpi-value {
    font-size: 2rem;
    font-weight: 700;
    color: #1e293b;
    line-height: 1.2;
}
.kpi-label {
    font-size: 0.78rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: #6b7280;
    margin-top: 0.25rem;
}
.kpi-delta-pos { color: #10b981; font-size: 0.82rem; }
.kpi-delta-neg { color: #ef4444; font-size: 0.82rem; }
/* ---- Section header ---- */
.section-header {
    font-size: 1.35rem;
    font-weight: 700;
    color: #1e293b;
    border-left: 4px solid #3b82f6;
    padding-left: 0.75rem;
    margin-bottom: 0.5rem;
}
/* ---- Insight card ---- */
.insight-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-left: 4px solid #3b82f6;
    border-radius: 8px;
    padding: 1rem 1.25rem;
    margin-bottom: 0.9rem;
}
.insight-title {
    font-size: 0.95rem;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 0.3rem;
}
.insight-text { font-size: 0.88rem; color: #374151; }
.insight-metric {
    background: #f0f9ff;
    border-radius: 5px;
    padding: 0.3rem 0.6rem;
    font-size: 0.82rem;
    font-family: monospace;
    color: #0369a1;
    display: inline-block;
    margin: 0.35rem 0;
}
/* ---- Filter strip ---- */
.filter-tag {
    display: inline-block;
    background: #dbeafe;
    color: #1d4ed8;
    border-radius: 999px;
    padding: 0.15rem 0.6rem;
    font-size: 0.78rem;
    font-weight: 500;
    margin: 0.15rem;
}
/* ---- Divider ---- */
.hr-divider { border-top: 1px solid #e5e7eb; margin: 1rem 0; }
</style>
"""


def inject_css():
    """Inject custom CSS into the Streamlit app."""
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────
# KPI cards
# ─────────────────────────────────────────────────────────────────

def kpi_card(label: str, value: str, delta: str = "", delta_pos: bool = True) -> str:
    """Return HTML for a styled KPI card."""
    delta_cls = "kpi-delta-pos" if delta_pos else "kpi-delta-neg"
    delta_html = f'<div class="{delta_cls}">{delta}</div>' if delta else ""
    return f"""
    <div class="kpi-card">
        <div class="kpi-value">{value}</div>
        <div class="kpi-label">{label}</div>
        {delta_html}
    </div>
    """


def render_kpi_row(kpis: dict):
    """Render a row of KPI metric cards."""
    total    = kpis["total_employees"]
    left     = kpis["employees_left"]
    stayed   = kpis["employees_stayed"]
    rate     = kpis["attrition_rate"]
    avg_age  = kpis["avg_age"]
    avg_inc  = kpis["avg_monthly_income"]
    avg_ten  = kpis["avg_tenure"]

    cols = st.columns(7)
    data = [
        ("Total Employees",   f"{total:,}",          "",                True),
        ("Employees Left",    f"{left:,}",            "↑ risk flag",     False),
        ("Employees Stayed",  f"{stayed:,}",          "",                True),
        ("Attrition Rate",    f"{rate:.1f}%",         "overall",         rate < 15),
        ("Avg Age",           f"{avg_age:.1f} yrs",   "",                True),
        ("Avg Monthly Income",f"${avg_inc:,.0f}",     "",                True),
        ("Avg Tenure",        f"{avg_ten:.1f} yrs",   "",                True),
    ]
    for col, (lbl, val, delta, pos) in zip(cols, data):
        col.markdown(kpi_card(lbl, val, delta, pos), unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────
# Download helpers
# ─────────────────────────────────────────────────────────────────

def df_to_csv_bytes(df: pd.DataFrame) -> bytes:
    """Convert DataFrame to UTF-8 encoded CSV bytes."""
    return df.to_csv(index=False).encode("utf-8")


def download_button(df: pd.DataFrame, label: str, filename: str):
    """Render a Streamlit download button for a DataFrame as CSV."""
    st.download_button(
        label=f"⬇ {label}",
        data=df_to_csv_bytes(df),
        file_name=filename,
        mime="text/csv",
    )


# ─────────────────────────────────────────────────────────────────
# Section header helper
# ─────────────────────────────────────────────────────────────────

def section_header(title: str):
    """Render a styled section header."""
    st.markdown(f'<div class="section-header">{title}</div>', unsafe_allow_html=True)


def insight_card(title: str, observation: str, metric: str, interpretation: str):
    """Render a styled insight card."""
    html = f"""
    <div class="insight-card">
        <div class="insight-title">💡 {title}</div>
        <div class="insight-text">{observation}</div>
        <div class="insight-metric">{metric}</div>
        <div class="insight-text" style="margin-top:0.4rem; color:#6b7280;">
            {interpretation}
        </div>
    </div>
    """
    st.markdown(html, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────
# Sidebar filter builder
# ─────────────────────────────────────────────────────────────────

def apply_sidebar_filters(df: pd.DataFrame) -> pd.DataFrame:
    """
    Render sidebar filter widgets and return a filtered copy of df.
    """
    st.sidebar.markdown("---")
    st.sidebar.markdown("#### 🔍 Global Filters")

    filtered = df.copy()

    def multiselect_filter(col: str, label: str):
        options = sorted(df[col].dropna().unique().tolist(), key=str)
        chosen  = st.sidebar.multiselect(label, options, default=options, key=f"filter_{col}")
        return chosen

    dept_filter  = multiselect_filter("Department",    "Department")
    role_filter  = multiselect_filter("JobRole",       "Job Role")
    gender_filter= multiselect_filter("Gender",        "Gender")
    ag_filter    = multiselect_filter("AgeGroup",      "Age Group")
    jl_filter    = multiselect_filter("JobLevel",      "Job Level")
    ot_filter    = multiselect_filter("OverTime",      "Overtime")
    bt_filter    = multiselect_filter("BusinessTravel","Business Travel")
    ms_filter    = multiselect_filter("MaritalStatus", "Marital Status")
    at_filter    = multiselect_filter("Attrition",     "Attrition")

    filtered = filtered[
        filtered["Department"].isin(dept_filter) &
        filtered["JobRole"].isin(role_filter) &
        filtered["Gender"].isin(gender_filter) &
        filtered["AgeGroup"].isin(ag_filter) &
        filtered["JobLevel"].isin(jl_filter) &
        filtered["OverTime"].isin(ot_filter) &
        filtered["BusinessTravel"].isin(bt_filter) &
        filtered["MaritalStatus"].isin(ms_filter) &
        filtered["Attrition"].isin(at_filter)
    ]

    if st.sidebar.button("↺ Reset Filters"):
        st.rerun()

    st.sidebar.markdown(f"**{len(filtered):,}** employees shown")
    return filtered
