"""
analysis.py
-----------
Core analytical functions: attrition rates, segment analysis, summaries.
"""

import pandas as pd
import numpy as np


# ─────────────────────────────────────────────
# Attrition rate helpers
# ─────────────────────────────────────────────

def attrition_by_column(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """
    Return a DataFrame with employee count, number who left,
    and attrition rate grouped by `col`.
    """
    grp = df.groupby(col, observed=True).agg(
        Total=("AttritionFlag", "count"),
        Left=("AttritionFlag", "sum"),
    ).reset_index()
    grp["Stayed"]        = grp["Total"] - grp["Left"]
    grp["AttritionRate"] = (grp["Left"] / grp["Total"] * 100).round(2)
    return grp.sort_values("AttritionRate", ascending=False)


def attrition_by_two_columns(df: pd.DataFrame, col1: str, col2: str) -> pd.DataFrame:
    """Return pivot of attrition rates across two categorical variables."""
    grp = df.groupby([col1, col2], observed=True).agg(
        Total=("AttritionFlag", "count"),
        Left=("AttritionFlag", "sum"),
    ).reset_index()
    grp["AttritionRate"] = (grp["Left"] / grp["Total"] * 100).round(2)
    return grp


def attrition_pivot(df: pd.DataFrame, row_col: str, col_col: str) -> pd.DataFrame:
    """
    Return a pivot table of attrition rates where rows = row_col categories
    and columns = col_col categories.
    """
    grp = attrition_by_two_columns(df, row_col, col_col)
    return grp.pivot(index=row_col, columns=col_col, values="AttritionRate")


# ─────────────────────────────────────────────
# Segment analysis
# ─────────────────────────────────────────────

def segment_analysis(df: pd.DataFrame, variables: list[str], min_n: int = 10) -> pd.DataFrame:
    """
    Group by one to three variables and compute attrition rate per segment.
    Filters segments with fewer than `min_n` employees.
    """
    valid = [v for v in variables if v and v in df.columns]
    if not valid:
        return pd.DataFrame()

    grp = df.groupby(valid, observed=True).agg(
        Total=("AttritionFlag", "count"),
        Left=("AttritionFlag", "sum"),
    ).reset_index()
    grp["Stayed"]        = grp["Total"] - grp["Left"]
    grp["AttritionRate"] = (grp["Left"] / grp["Total"] * 100).round(2)
    return grp[grp["Total"] >= min_n].sort_values("AttritionRate", ascending=False)


# ─────────────────────────────────────────────
# Compensation analysis
# ─────────────────────────────────────────────

def income_stats_by_group(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Return median and mean monthly income per group."""
    return (
        df.groupby(col, observed=True)["MonthlyIncome"]
        .agg(Median="median", Mean="mean", Count="count")
        .reset_index()
        .round(2)
    )


def income_by_attrition(df: pd.DataFrame) -> pd.DataFrame:
    """Return income statistics split by attrition status."""
    return (
        df.groupby("Attrition", observed=True)["MonthlyIncome"]
        .describe()
        .round(2)
        .reset_index()
    )


# ─────────────────────────────────────────────
# Overtime analysis
# ─────────────────────────────────────────────

def overtime_attrition_by_role(df: pd.DataFrame) -> pd.DataFrame:
    """Return attrition rate split by JobRole and OverTime."""
    return attrition_by_two_columns(df, "JobRole", "OverTime")


# ─────────────────────────────────────────────
# Career growth analysis
# ─────────────────────────────────────────────

def tenure_vs_attrition(df: pd.DataFrame, tenure_col: str, bins: int = 10) -> pd.DataFrame:
    """Bin a continuous tenure variable and compute per-bin attrition rate."""
    col_bin = f"{tenure_col}_bin"
    df = df.copy()
    df[col_bin] = pd.cut(df[tenure_col], bins=bins)
    grp = df.groupby(col_bin, observed=True).agg(
        Total=("AttritionFlag", "count"),
        Left=("AttritionFlag", "sum"),
    ).reset_index()
    grp["AttritionRate"] = (grp["Left"] / grp["Total"] * 100).round(2)
    grp[col_bin] = grp[col_bin].astype(str)
    return grp


# ─────────────────────────────────────────────
# Key insights auto-generation
# ─────────────────────────────────────────────

def generate_key_insights(df: pd.DataFrame) -> list[dict]:
    """
    Auto-generate 8–10 evidence-based insights from the data.
    Each insight is a dict with keys: title, observation, metric, interpretation.
    """
    insights = []

    total     = len(df)
    left      = int(df["AttritionFlag"].sum())
    attr_rate = left / total * 100

    # 1. Overall attrition
    insights.append({
        "title": "Overall Attrition Rate",
        "observation": f"{attr_rate:.1f}% of employees in this dataset left the organisation.",
        "metric": f"{left} out of {total} employees ({attr_rate:.1f}%)",
        "interpretation": (
            "An attrition rate above 15% typically warrants investigation into retention strategies. "
            "The dataset shows where potential improvement opportunities may exist."
        ),
    })

    # 2. Overtime
    ot = attrition_by_column(df, "OverTime")
    ot_yes = ot.loc[ot["OverTime"] == "Yes", "AttritionRate"].values
    ot_no  = ot.loc[ot["OverTime"] == "No",  "AttritionRate"].values
    if len(ot_yes) and len(ot_no):
        insights.append({
            "title": "Overtime & Attrition",
            "observation": (
                f"Employees who work overtime show a higher observed attrition rate "
                f"({ot_yes[0]:.1f}%) compared with those who do not ({ot_no[0]:.1f}%)."
            ),
            "metric": f"Overtime Yes: {ot_yes[0]:.1f}% | No: {ot_no[0]:.1f}%",
            "interpretation": (
                "Overwork is associated with attrition in this dataset. "
                "This does not establish causation but suggests workload as a factor worth examining."
            ),
        })

    # 3. Job satisfaction
    js = attrition_by_column(df, "JobSatisfaction")
    if not js.empty:
        low  = js.loc[js["JobSatisfaction"] == 1, "AttritionRate"].values
        high = js.loc[js["JobSatisfaction"] == 4, "AttritionRate"].values
        if len(low) and len(high):
            insights.append({
                "title": "Job Satisfaction Gradient",
                "observation": (
                    f"Employees with the lowest job satisfaction (1) show an attrition rate "
                    f"of {low[0]:.1f}%, compared with {high[0]:.1f}% for those with the highest (4)."
                ),
                "metric": f"Satisfaction 1: {low[0]:.1f}% | Satisfaction 4: {high[0]:.1f}%",
                "interpretation": (
                    "The dataset indicates a notable difference in attrition rates across job "
                    "satisfaction levels, suggesting satisfaction may be a meaningful retention signal."
                ),
            })

    # 4. Department
    dept = attrition_by_column(df, "Department")
    if not dept.empty:
        top = dept.iloc[0]
        insights.append({
            "title": f"Highest Attrition Department: {top['Department']}",
            "observation": (
                f"The {top['Department']} department shows the highest observed attrition rate "
                f"at {top['AttritionRate']:.1f}% ({top['Left']} out of {top['Total']} employees)."
            ),
            "metric": f"{top['Left']}/{top['Total']} = {top['AttritionRate']:.1f}%",
            "interpretation": (
                "Department-level attrition differences may reflect differences in role demands, "
                "culture, compensation, or career pathways."
            ),
        })

    # 5. Age group
    ag = attrition_by_column(df, "AgeGroup")
    if not ag.empty:
        top_ag = ag.iloc[0]
        insights.append({
            "title": f"Age Group with Highest Attrition: {top_ag['AgeGroup']}",
            "observation": (
                f"The {top_ag['AgeGroup']} age group shows the highest observed attrition rate "
                f"of {top_ag['AttritionRate']:.1f}%."
            ),
            "metric": f"{top_ag['Left']}/{top_ag['Total']} = {top_ag['AttritionRate']:.1f}%",
            "interpretation": (
                "Younger employees may be at higher risk of attrition, possibly due to fewer "
                "seniority benefits, broader job market exploration, or unmet growth expectations."
            ),
        })

    # 6. Income
    inc = income_by_attrition(df)
    yes_median = df[df["Attrition"] == "Yes"]["MonthlyIncome"].median()
    no_median  = df[df["Attrition"] == "No"]["MonthlyIncome"].median()
    insights.append({
        "title": "Income Differential",
        "observation": (
            f"Employees who left had a median monthly income of ${yes_median:,.0f}, "
            f"while those who stayed had a median of ${no_median:,.0f}."
        ),
        "metric": f"Left median: ${yes_median:,.0f} | Stayed median: ${no_median:,.0f}",
        "interpretation": (
            "Lower compensation was associated with higher attrition in this dataset. "
            "Competitive pay may be a relevant retention factor."
        ),
    })

    # 7. Work-life balance
    wlb = attrition_by_column(df, "WorkLifeBalance")
    if not wlb.empty:
        low_wlb  = wlb.loc[wlb["WorkLifeBalance"] == 1, "AttritionRate"].values
        best_wlb = wlb.loc[wlb["WorkLifeBalance"] == 4, "AttritionRate"].values
        if len(low_wlb):
            insights.append({
                "title": "Work-Life Balance & Attrition",
                "observation": (
                    f"Employees reporting the lowest work-life balance (1) show an attrition "
                    f"rate of {low_wlb[0]:.1f}%."
                ),
                "metric": f"WLB 1: {low_wlb[0]:.1f}%" + (
                    f" | WLB 4: {best_wlb[0]:.1f}%" if len(best_wlb) else ""
                ),
                "interpretation": (
                    "Poor work-life balance is associated with higher attrition in this dataset."
                ),
            })

    # 8. Business travel
    bt = attrition_by_column(df, "BusinessTravel")
    if not bt.empty and "Travel_Frequently" in bt["BusinessTravel"].values:
        freq = bt.loc[bt["BusinessTravel"] == "Travel_Frequently", "AttritionRate"].values
        rare = bt.loc[bt["BusinessTravel"] == "Travel_Rarely",     "AttritionRate"].values
        none = bt.loc[bt["BusinessTravel"] == "Non-Travel",        "AttritionRate"].values
        if len(freq):
            insights.append({
                "title": "Frequent Travel & Attrition",
                "observation": (
                    f"Employees who travel frequently show an attrition rate of {freq[0]:.1f}%, "
                    + (f"vs {rare[0]:.1f}% for rare travelers" if len(rare) else "")
                    + (f" and {none[0]:.1f}% for non-travelers." if len(none) else ".")
                ),
                "metric": f"Frequent: {freq[0]:.1f}%",
                "interpretation": (
                    "Frequent travel may contribute to work-life balance challenges and was "
                    "associated with higher attrition in this dataset."
                ),
            })

    # 9. Stock options
    so = attrition_by_column(df, "StockOptionLevel")
    if not so.empty:
        no_stock  = so.loc[so["StockOptionLevel"] == 0, "AttritionRate"].values
        has_stock = so[so["StockOptionLevel"] > 0]["Left"].sum() / so[so["StockOptionLevel"] > 0]["Total"].sum() * 100
        if len(no_stock):
            insights.append({
                "title": "Stock Options & Retention",
                "observation": (
                    f"Employees with no stock options (level 0) show an attrition rate of "
                    f"{no_stock[0]:.1f}%, compared with {has_stock:.1f}% for those with any stock options."
                ),
                "metric": f"No stock: {no_stock[0]:.1f}% | Has stock: {has_stock:.1f}%",
                "interpretation": (
                    "Equity ownership was associated with lower attrition in this dataset, "
                    "suggesting financial stakes in company success may improve retention."
                ),
            })

    # 10. Years since last promotion
    promo = tenure_vs_attrition(df, "YearsSinceLastPromotion", bins=6)
    if not promo.empty:
        max_row = promo.loc[promo["AttritionRate"].idxmax()]
        insights.append({
            "title": "Promotion Recency & Attrition",
            "observation": (
                f"Employees in the tenure bin with the highest attrition went {max_row['YearsSinceLastPromotion_bin']} "
                f"years since their last promotion, showing a {max_row['AttritionRate']:.1f}% attrition rate."
            ),
            "metric": f"{max_row['Left']} left / {max_row['Total']} total = {max_row['AttritionRate']:.1f}%",
            "interpretation": (
                "Longer periods without promotion may be associated with higher attrition, "
                "suggesting career progression opportunities matter to employee retention."
            ),
        })

    return insights
